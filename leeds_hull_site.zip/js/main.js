// main.js
console.log('Script loaded');
